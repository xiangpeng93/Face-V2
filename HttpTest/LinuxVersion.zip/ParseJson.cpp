#include "ParseJson.h"
#include <stdio.h>

CParseJson::CParseJson()
{
}


CParseJson::~CParseJson()
{
}


std::string CParseJson::parseString(const std::string& input,
	Json::Value* root,
	std::string type)
{
	Json::Features features;
	Json::Reader reader(features);
	bool parsingSuccessful = reader.parse(input, *root);
	if (!root) {
		printf("Failed to parse file: \n%s\n",
			reader.getFormattedErrorMessages().c_str());
		return "";
	}

	return (*root)["face"][0]["face_id"].asString();  // 访问节点，upload_id = "UP000000" 
}

int CParseJson::getJsonValue(const std::string& input,
	Json::Value* root)
{
	Json::Features features;
	Json::Reader reader(features);
	bool parsingSuccessful = reader.parse(input, *root);
	if (!root) {
		
		return -1;
	}

	return 0;  // ·ÃÎÊœÚµã£¬upload_id = "UP000000" 
}